<?php
/**
 * @package		JomSocial
 * @subpackage 	Template 
 * @copyright (C) 2008 by Slashes & Dots Sdn Bhd - All rights reserved!
 * @license		GNU/GPL, see LICENSE.php
 */
defined('_JEXEC') or die();
?>
Hi {target},

{actor} just posted a wall message. 

Message:

<?php echo $message; ?>

You can read the message at:


<a href="{url}">{url}</a>


Have a nice day!

