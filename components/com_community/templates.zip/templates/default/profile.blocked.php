<div style="border:1px solid #FF0000; padding:20px; background-color:#FFEAEA">
	<?php echo JText::_('CC USER ACCOUNT IS BANNED');?>
</div>