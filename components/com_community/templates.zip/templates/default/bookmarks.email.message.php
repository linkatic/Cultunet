Hi there,

A user would like to share a link with you.

You can view the link at:
<?php echo $uri; ?>

<?php
if( !empty($message) )
{
?>
Message:
===============================================================================

<?php echo $message; ?>

===============================================================================
<?php
}
?>