Hi {target},

{actor} just approved your friend request. You are now friends with {actor}.

You can view {actor}'s profile here:

<?php echo $url; ?>


Have a nice day!
