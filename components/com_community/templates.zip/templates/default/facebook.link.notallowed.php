<?php
defined('_JEXEC') or die();
?>
<div><?php echo JText::_('CC ADMIN NOT ALLOWED TO ASSOCIATE FACEBOOK');?></div>