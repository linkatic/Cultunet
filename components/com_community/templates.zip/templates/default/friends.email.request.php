Hi {target},

{actor} added you as friend. You still need to approve this request. 
<?php if(!empty($message)){echo '
    '.$message.'
';} ?>

To add {actor} as your friend, just go to your friends request page below:

<?php echo $url; ?>


Have a nice day!
