Hi {target},

{actor} invited you to join an event (<?php echo $eventtitle;?>). Below is a message that is sent by {actor},

Message:

<?php echo $message; ?>

To view the event, access the URL at the following location:

<?php echo $url; ?>


Have a nice day!

