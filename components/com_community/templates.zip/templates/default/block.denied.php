<?php
/**
 * @package	JomSocial
 * @copyright (C) 2008 by Slashes & Dots Sdn Bhd - All rights reserved!
 * @license		GNU/GPL, see LICENSE.php
 */
 
// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die();
?>
<table class="blockUnregister" cellpadding="0" cellspacing="0" border="0">
	<tr>
		<td colspan="2" valign="top" align="center">
			<div class="message" style="margin-bottom: 10px;"><?php echo JText::_('CC YOU ARE BLOCKED BY USER');?></div>
		</td>
	</tr>
</table>